//
//  ViewController.m
//  StudyFMDB
//
//  Created by limin on 16/11/30.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import "MainViewController.h"
#import "LMListBar.h"
#import "LMArrow.h"
#import "LMDetailsList.h"
#import "LMDeleteBar.h"
#import "LMScroller.h"


//cell
#import "LMCollectionViewCell.h"
#import "LMListModel.h"
#import "LMTopicsModel.h"
#import "DataBaseTool.h"

//tool
#import <MJExtension.h>
#import <Reachability.h>
#import "MBProgressHUD+LM.h"

@interface MainViewController () <UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property (nonatomic,strong) LMListBar *listBar;

@property (nonatomic,strong) LMDeleteBar *deleteBar;

@property (nonatomic,strong) LMDetailsList *detailsList;

@property (nonatomic,strong) LMArrow *arrow;

@property (nonatomic,strong) UICollectionView *mainCollection;
/* 标签字典 */
@property(nonatomic,strong)NSDictionary *tagDict;
/* 上面的标签 */
@property(nonatomic,strong)NSMutableArray *listTopTitle;
/* 下面的标签 */
@property(nonatomic,strong)NSMutableArray *listBottomTitle;
/* 所有的标签model */
@property(nonatomic,strong)NSMutableArray *listAllModel;
@end
static NSString *cellid = @"collectionCellID";
@implementation MainViewController
#pragma mark - 懒加载
-(NSMutableArray *)listTopTitle
{
    if (!_listTopTitle) {
        _listTopTitle = [[NSMutableArray alloc] init];
    }
    return _listTopTitle;
}
-(NSMutableArray *)listBottomTitle
{
    if (!_listBottomTitle) {
        _listBottomTitle = [[NSMutableArray alloc] init];
    }
    return _listBottomTitle;
}
-(NSMutableArray *)listAllModel
{
    if (!_listAllModel) {
        _listAllModel = [[NSMutableArray alloc]init];
    }
    return _listAllModel;
}
#pragma mark - 视图管理
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //取出list.plist的路径
    NSString *path = [[NSBundle mainBundle]pathForResource:@"list" ofType:@"plist"];
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:path];
    NSArray *listTopModel = [LMListModel mj_objectArrayWithKeyValuesArray:dict[@"top"]];
    NSArray *listBottomModel = [LMListModel mj_objectArrayWithKeyValuesArray:dict[@"bottom"]];
    //从偏好里面取出值
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    //最新的所有标签
    NSMutableArray *listAll = [NSMutableArray arrayWithArray:listTopModel];
    [listAll addObjectsFromArray:listBottomModel];
    [self.listAllModel removeAllObjects];
    [self.listAllModel addObjectsFromArray:listAll];
    //如果从服务器取到标签在原来存储的偏好设置里面没有，移除掉该标签。
    //
    NSMutableArray *tempTop = [userDefault valueForKey:topTitlesKey];
    NSMutableArray *top = [[NSMutableArray alloc]initWithArray:tempTop];
    if (top.count>0) {
        for (int i=0 ; i<top.count;i++){
            NSString *title = top[i];
            BOOL isHave = NO;
            for (LMListModel *model in listAll) {
                if ([title isEqualToString:model.title]) {
                    isHave = YES;
                    break;
                }
            }
            if (!isHave) {//yes：有。no：无
                [top removeObject:title];
            }
        }
        
        //赋值
        [self.listTopTitle removeAllObjects];
        [self.listBottomTitle removeAllObjects];
        [self.listTopTitle addObjectsFromArray:top];
        // bottom = all-top ;
        NSMutableArray *alltitle = [[NSMutableArray alloc]init];
        for (LMListModel *model in listAll) {
            [alltitle addObject: model.title];
        }
        [alltitle removeObjectsInArray:top];
        [self.listBottomTitle addObjectsFromArray:alltitle];
        
    }else//第一次存储
    {
        for (LMListModel *model in listTopModel) {
            [self.listTopTitle addObject: model.title];
        }
        for (LMListModel *model in listBottomModel) {
            [self.listBottomTitle addObject: model.title];
        }
        
    }
    //重新存储
    [userDefault setValue:self.listTopTitle forKey:topTitlesKey];
    [userDefault setValue:self.listBottomTitle forKey:bottomTitlesKey];
    [userDefault synchronize];
    
    [self makeContent];
    [self.mainCollection reloadData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupNaviBar];
    //注册通知
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refreshCollectionView) name:@"TabChangedRefreshMainVC" object:nil];
    
}
-(void)setupNaviBar
{
    self.view.backgroundColor = [UIColor whiteColor];
    [self.navigationController.navigationBar setTranslucent:NO];
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"nav_bg"] forBarMetrics:UIBarMetricsDefault];
}


-(void)makeContent
{
    __weak typeof(self) unself = self;
    
    if (!self.detailsList) {
        self.detailsList = [[LMDetailsList alloc] initWithFrame:CGRectMake(0, kListBarH-kScreenH, kScreenW, kScreenH-kListBarH)];
        self.detailsList.scrollsToTop = NO;
        self.detailsList.listAll = [NSMutableArray arrayWithObjects:self.listTopTitle,self.listBottomTitle, nil];
        self.detailsList.longPressedBlock = ^(){
            [unself.deleteBar sortBtnClick:unself.deleteBar.sortBtn];
        };
        self.detailsList.opertionFromItemBlock = ^(animateType type, NSString *itemName, int index){
            [unself.listBar operationFromBlock:type itemName:itemName index:index];
        };
        [self.view addSubview:self.detailsList];
    }
    
    if (!self.listBar) {
        self.listBar = [[LMListBar alloc] initWithFrame:CGRectMake(0, 0, kScreenW, kListBarH)];
        self.listBar.scrollsToTop = NO;
        self.listBar.visibleItemList = self.listTopTitle;
        self.listBar.arrowChange = ^(){
            if (unself.arrow.arrowBtnClick) {
                unself.arrow.arrowBtnClick();
            }
        };
        self.listBar.listBarItemClickBlock = ^(NSString *itemName , NSInteger itemIndex){
            [unself.detailsList itemRespondFromListBarClickWithItemName:itemName];
            //添加scrollview
            
            //移动到该位置
            unself.mainCollection.contentOffset =  CGPointMake(itemIndex * unself.mainCollection.frame.size.width, 0);
        };
        [self.view addSubview:self.listBar];
    }
    
    if (!self.deleteBar) {
        self.deleteBar = [[LMDeleteBar alloc] initWithFrame:self.listBar.frame];
        [self.view addSubview:self.deleteBar];
    }
    
    
    if (!self.arrow) {
        self.arrow = [[LMArrow alloc] initWithFrame:CGRectMake(kScreenW-kArrowW, 0, kArrowW, kListBarH)];
        self.arrow.arrowBtnClick = ^(){
            unself.deleteBar.hidden = !unself.deleteBar.hidden;
            [UIView animateWithDuration:kAnimationTime animations:^{
                CGAffineTransform rotation = unself.arrow.imageView.transform;
                unself.arrow.imageView.transform = CGAffineTransformRotate(rotation,M_PI);
                unself.detailsList.transform = (unself.detailsList.frame.origin.y<0)?CGAffineTransformMakeTranslation(0, kScreenH):CGAffineTransformMakeTranslation(0, -kScreenH);
                
            }];
        };
        [self.view addSubview:self.arrow];
    }
    
    if (!self.mainCollection) {
        //布局样式
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
        //定义每个collectionview的大小
        layout.itemSize = CGSizeMake(kScreenW, kScreenH-kListBarH-kNavHeight);
        //定义每个uicollectionview横向间距
        layout.minimumLineSpacing = 0;
        //定义每个uicollectionview纵向间距
        layout.minimumInteritemSpacing = 0;
        //滑动方向
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        //创建collectionview
        self.mainCollection = [[UICollectionView alloc] initWithFrame:CGRectMake(0, kListBarH, kScreenW , kScreenH-kListBarH-kNavHeight) collectionViewLayout:layout];
        
        self.mainCollection.backgroundColor = [UIColor whiteColor];
        self.mainCollection.bounces = NO;
        self.mainCollection.pagingEnabled = YES;
        self.mainCollection.showsHorizontalScrollIndicator = NO;
        self.mainCollection.showsVerticalScrollIndicator = NO;
        self.mainCollection.delegate = self;
        self.mainCollection.dataSource = self;
        [self.mainCollection registerClass:[LMCollectionViewCell class] forCellWithReuseIdentifier:cellid];
        [self.view insertSubview:self.mainCollection atIndex:0];
        

    }
}
#pragma mark - 刷新页面
-(void)refreshCollectionView
{
    //取出最新的标签数据，刷新控制器
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    [self.listTopTitle removeAllObjects];
    [self.listBottomTitle removeAllObjects];
    [self.listTopTitle addObjectsFromArray:[userDefault valueForKey:topTitlesKey]];
    [self.listBottomTitle addObjectsFromArray:[userDefault valueForKey:bottomTitlesKey]];
    //刷新
    [self.mainCollection reloadData];
    [self.mainCollection layoutIfNeeded];
    //重新计算偏移量
    for (int i=0; i<self.listTopTitle.count; i++) {
        if ([self.listTopTitle[i] isEqualToString:self.listBar.btnSelect.currentTitle]) {
            self.mainCollection.contentOffset = CGPointMake(i*kScreenW, 0);
            //再次点击当前被选中的。
            [self.listBar itemClickByScrollerWithIndex:i];
        }
    }
}
#pragma mark - <UICollectionViewDataSource>
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.listTopTitle.count;
}
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    LMCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellid forIndexPath:indexPath];
    LMListModel *model = self.listAllModel[indexPath.item];
    cell.titleStr = model.title;
    cell.idStr = model.Id;
    return cell;
}
#pragma mark - 头部显示的内容
//-(UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
//{
//    UICollectionReusableView *headView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"ReusableView" forIndexPath:indexPath];
//    //轮播
//    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, 100)];
//    view.backgroundColor = [UIColor redColor];
//    [headView addSubview:view];
//    return headView;
//}
#pragma mark -UIScrollView Delegate
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [self.listBar itemClickByScrollerWithIndex:scrollView.contentOffset.x / self.mainCollection.frame.size.width];
}
#pragma mark - <UICollectionViewDelegate>
- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath NS_AVAILABLE_IOS(8_0)
{
    NSString *currentTitle = self.listTopTitle[indexPath.item];
    NSString *currentID ;
    for (LMListModel *model in self.listAllModel) {
        if([model.title isEqualToString:currentTitle]){
            currentID = model.Id;
            break;
        }
    }
    NSLog(@"将要显示%@,%@",currentTitle,currentID);
    //主键
    NSString *private_key = [NSString stringWithFormat:@"%@%@",currentTitle,currentID];
    
    //判断是否有网络
    Reachability *reach = [Reachability reachabilityForInternetConnection];
    NetworkStatus status = [reach currentReachabilityStatus];
    if(status == NotReachable)//无网，从数据库取出后赋值
    {
//        [MBProgressHUD showError:@"请检查网络后重试"];
        //从数据库取出
        NSMutableArray *dbModelArray = [[DataBaseTool shareDataBaseTool]queryModelArrayByPrKey:private_key];
        //当前的类别cell
        LMCollectionViewCell *colCell = (LMCollectionViewCell *)cell;
        colCell.modelArray = dbModelArray;
        
    }else//请求数据
    {
        NSDictionary *dict = @{
                               @"a":@"list",
                               @"c":@"data",
                               @"type":currentID
                               };
        NSString *urlPath = @"http://api.budejie.com/api/api_open.php";
        [NetWorkTool NetRequestWithBaseURL:urlPath andAppendURL:@"" RequestWay:@"GET" Parameters:dict finished:^(id data) {
            //
//            NSLog(@"%@",data);
            NSArray *tempArray = [LMTopicsModel mj_objectArrayWithKeyValuesArray:data[@"list"]];
            
            //当前的类别cell
            LMCollectionViewCell *colCell = (LMCollectionViewCell *)cell;
            //刷新控件
            colCell.modelArray = tempArray;
            NSString *max = data[@"info"][@"maxtime"];
            for(LMTopicsModel *model in tempArray)
            {
                model.maxtime = max;
            }
            //存储数据
            [[DataBaseTool shareDataBaseTool]deleteModelArrayByPrKey:private_key];
            [[DataBaseTool shareDataBaseTool]insertModelArray:[NSMutableArray arrayWithArray:tempArray] byPrKey:private_key];
            
            
            
        } failure:^(NSError *error) {
            //从数据库取出
            NSMutableArray *dbModelArray = [[DataBaseTool shareDataBaseTool]queryModelArrayByPrKey:private_key];
            //当前的类别cell
            LMCollectionViewCell *colCell = (LMCollectionViewCell *)cell;
            colCell.modelArray = dbModelArray;
        }];
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
