//
//  LMCollectionViewCell.m
//  StudyFMDB
//
//  Created by limin on 16/11/30.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import "LMCollectionViewCell.h"
#import "LMTopicsCell.h"
#import "LMTopicsModel.h"
#import "DataBaseTool.h"

#import <MJExtension.h>
#import <MJRefresh.h>
#import <Reachability.h>
@interface LMCollectionViewCell()<UITableViewDelegate,UITableViewDataSource>
/* 表格 */
@property(nonatomic,strong)UITableView *lmTableView;
@end
static NSString *const LMTopicsCellID = @"TopicsCell";
@implementation LMCollectionViewCell
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = kBgColor;
        //创建表
        self.lmTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, kScreenH-kNavHeight-kListBarH)];
        self.lmTableView.delegate = self;
        self.lmTableView.dataSource = self;
        //注册
        [self.lmTableView registerNib:[UINib nibWithNibName:NSStringFromClass([LMTopicsCell class]) bundle:nil] forCellReuseIdentifier:LMTopicsCellID];
    
        [self addSubview:self.lmTableView];
        //创建刷新控件
        [self addRefreshView];
        
    }
    return self;
}
-(void)addRefreshView
{
    self.lmTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(requestNewData)];
    self.lmTableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(requestMoreData)];
    
}
-(void)setIdStr:(NSString *)idStr
{
    _idStr = idStr;
    NSLog(@"%@%@",self.titleStr,idStr);
    self.lmTableView.backgroundColor = kBgColor;
    
}
-(void)setModelArray:(NSArray *)modelArray
{
    _modelArray = modelArray;
    [self.lmTableView reloadData];
}
#pragma mark - 请求最新的数据
-(void)requestNewData
{
    [self.lmTableView.mj_footer endRefreshing];
    //
    /**
     *判断是否有网路:
     *1:无网（从本地数据库取出）,2:有网(A:请求到数据：删除原来的本地数据，把新的加进去，B:failed:从本地数据取出)
     */
    NSLog(@"将要显示%@,%@",self.titleStr,self.idStr);
    //主键
    NSString *private_key = [NSString stringWithFormat:@"%@%@",self.titleStr,self.idStr];
    
    //判断是否有网络
    Reachability *reach = [Reachability reachabilityForInternetConnection];
    NetworkStatus status = [reach currentReachabilityStatus];
    if(status == NotReachable)//无网，从数据库取出后赋值
    {
        //        [MBProgressHUD showError:@"请检查网络后重试"];
        //从数据库取出
        NSMutableArray *dbModelArray = [[DataBaseTool shareDataBaseTool]queryModelArrayByPrKey:private_key];
        //数据赋值
        self.modelArray = dbModelArray;
        
    }else//请求数据
    {
        NSDictionary *dict = @{
                               @"a":@"list",
                               @"c":@"data",
                               @"type":self.idStr
                               };
        NSString *urlPath = @"http://api.budejie.com/api/api_open.php";
        __weak LMCollectionViewCell *weakSelf = self;
        [NetWorkTool NetRequestWithBaseURL:urlPath andAppendURL:@"" RequestWay:@"GET" Parameters:dict finished:^(id data) {
            //
            //            NSLog(@"%@",data);
            NSArray *tempArray = [LMTopicsModel mj_objectArrayWithKeyValuesArray:data[@"list"]];
            
            //当前的类别cell
            weakSelf.modelArray = tempArray;
            NSString *max = data[@"info"][@"maxtime"];
            for(LMTopicsModel *model in tempArray)
            {
                model.maxtime = max;
            }
            //存储数据
            [[DataBaseTool shareDataBaseTool]deleteModelArrayByPrKey:private_key];
            [[DataBaseTool shareDataBaseTool]insertModelArray:[NSMutableArray arrayWithArray:tempArray] byPrKey:private_key];
            //结束刷新
            [weakSelf.lmTableView.mj_header endRefreshing];
            
            
            
        } failure:^(NSError *error) {
            //结束刷新
            [weakSelf.lmTableView.mj_header endRefreshing];
            //从数据库取出
            NSMutableArray *dbModelArray = [[DataBaseTool shareDataBaseTool]queryModelArrayByPrKey:private_key];
            //当前的类别cell
            weakSelf.modelArray = dbModelArray;
        }];
    }
    
}
-(void)requestMoreData
{
    [self.lmTableView.mj_header endRefreshing];
    //
    /**
     *判断是否有网路:
     *1:无网（从本地数据库取出）,2:有网(A:请求到数据：在原来的本地数据基础上，把新的加进去，B:failed:从本地数据取出)
     */
    NSLog(@"将要显示%@,%@",self.titleStr,self.idStr);
    //主键
    NSString *private_key = [NSString stringWithFormat:@"%@%@",self.titleStr,self.idStr];
    
    //判断是否有网络
    Reachability *reach = [Reachability reachabilityForInternetConnection];
    NetworkStatus status = [reach currentReachabilityStatus];
    if(status == NotReachable)//无网，从数据库取出后赋值
    {
        //        [MBProgressHUD showError:@"请检查网络后重试"];
        //从数据库取出
        NSMutableArray *dbModelArray = [[DataBaseTool shareDataBaseTool]queryModelArrayByPrKey:private_key];
        //数据赋值
        self.modelArray = dbModelArray;
        
    }else//请求数据
    {
        LMTopicsModel *model = self.modelArray.lastObject;
        NSDictionary *dict = @{
                               @"a":@"list",
                               @"c":@"data",
                               @"type":self.idStr,
                               @"maxtime":model.maxtime
                               };
        NSString *urlPath = @"http://api.budejie.com/api/api_open.php";
        __weak LMCollectionViewCell *weakSelf = self;
        [NetWorkTool NetRequestWithBaseURL:urlPath andAppendURL:@"" RequestWay:@"GET" Parameters:dict finished:^(id data) {
            
            //            NSLog(@"%@",data);
            NSMutableArray *totalArray = [NSMutableArray arrayWithArray:weakSelf.modelArray];
            NSArray *tempArray = [LMTopicsModel mj_objectArrayWithKeyValuesArray:data[@"list"]];
            
            if (tempArray.count>0) {
                NSString *max = data[@"info"][@"maxtime"];
                for(LMTopicsModel *model in tempArray)
                {
                    model.maxtime = max;
                }
                //存储数据
                [[DataBaseTool shareDataBaseTool]insertModelArray:[NSMutableArray arrayWithArray:tempArray] byPrKey:private_key];
                
                [weakSelf.lmTableView.mj_footer endRefreshing];
            }else
            {
                [weakSelf.lmTableView.mj_footer endRefreshingWithNoMoreData];
            }
            //当前的类别cell
            [totalArray addObjectsFromArray:tempArray];
            weakSelf.modelArray = totalArray;
            
            
        } failure:^(NSError *error) {
            [weakSelf.lmTableView.mj_footer endRefreshing];
            //从数据库取出
            NSMutableArray *dbModelArray = [[DataBaseTool shareDataBaseTool]queryModelArrayByPrKey:private_key];
            //当前的类别cell
            weakSelf.modelArray = dbModelArray;
        }];
    }}
#pragma mark - <UITableViewDataSource>
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.modelArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    LMTopicsCell *topicsCell = [tableView dequeueReusableCellWithIdentifier:LMTopicsCellID];
    LMTopicsModel *model = self.modelArray[indexPath.row];
    topicsCell.topicsModel = model;
    topicsCell.selectionStyle = UITableViewCellSelectionStyleNone;
    return topicsCell;
}
#pragma mark - tableview delegate
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 200;
}
@end
