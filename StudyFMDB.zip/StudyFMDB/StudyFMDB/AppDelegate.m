//
//  AppDelegate.m
//  StudyFMDB
//
//  Created by limin on 16/11/30.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import "AppDelegate.h"
#import "MainViewController.h"

#import "ProjectTool.h"
#import <FMDB.h>

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    //创建主窗口
    self.window = [[UIWindow alloc] init];
    self.window.frame = [UIScreen mainScreen].bounds;
    self.window.backgroundColor = [UIColor whiteColor];
    //设置根控制器
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:[[MainViewController alloc]init]];
    self.window.rootViewController = nav;
    //显示窗口
    [self.window makeKeyAndVisible];
    //创建数据库
    [self createFMDB];
    return YES;
}
#pragma mark - 创建数据库
-(void)createFMDB
{
    NSString *dbFilePath = [ProjectTool getFMDBPath];
    /*
     为什么要往应用程序里添加数据库文件这个过程：
     因为下面要进行判断，会根据这个路径去查找应用程序的路径中到底有没有这个文件，
     如果有，则不用在此拷贝了，
     如果没有，则重新拷贝一次，
     数据库文件必须添加进取，否则无法进行数据库的操作，而且必须添加一次，
     
     那么为什么必须要添加一次呢？
     因为我们在程序中实现对数据库的修改，然而却又把数据库添加了一次，
     那么新添加的数据库就会把旧的数据库覆盖掉，那么程序中对数据库的修改也不能实现，
     所以数据库只能添加一次且是在程序运行初添加
     */
    
    //根据上面拼接好的路径 dbFilePath ，利用NSFileManager 类的对象的fileExistsAtPath方法来检测是否存在，返回一个BOOL值
    //1. 创建NSFileManager对象  NSFileManager包含了文件属性的方法
    NSFileManager *fm = [NSFileManager defaultManager];
    
    //2. 通过 NSFileManager 对象 fm 来判断文件是否存在，存在 返回YES  不存在返回NO
    BOOL isExist = [fm fileExistsAtPath:dbFilePath];
    //- (BOOL)fileExistsAtPath:(NSString *)path;
    
    //如果不存在 isExist = NO，拷贝工程里的数据库到Documents下
    if (!isExist)
    {
        //创建FMDB数据库
        FMDatabase *db = [FMDatabase databaseWithPath:dbFilePath];
        if ([db open]) {
            NSString *sql = [NSString stringWithFormat:@"CREATE TABLE %@(prikey TEXT,name TEXT,profile_image TEXT,text TEXT,create_time TEXT,ding TEXT,cai TEXT,repost TEXT,comment TEXT,sina_v TEXT,small_image TEXT,width TEXT,height TEXT,ID TEXT,maxtime TEXT)",dbTableName];
            BOOL res = [db executeUpdate:sql];
            if (!res) {
                NSLog(@"创建数据库失败");
            }else
            {
                NSLog(@"创建数据库成功！");
            }
            [db close];
        }else
        {
            NSLog(@"数据库打开失败");
        }
    }
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
