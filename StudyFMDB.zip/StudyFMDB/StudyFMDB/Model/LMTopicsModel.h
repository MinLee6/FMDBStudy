//
//  LMTopicsModel.h
//  百思不得姐
//
//  Created by limin on 16/6/21.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LMTopicsModel : NSObject
/* 名称 */
@property(nonatomic,copy)NSString *name;
/* 头像   */
@property(nonatomic,copy)NSString *profile_image;
/* 文本内容 */
@property(nonatomic,copy)NSString *text;
/* 发帖子时间 */
@property(nonatomic,copy)NSString *create_time;
/* 点赞数 */
@property(nonatomic,assign)NSInteger ding;
/* 踩数 */
@property(nonatomic,assign)NSInteger cai;
/* 转发数 */
@property(nonatomic,assign)NSInteger repost;
/* 评论数 */
@property(nonatomic,assign)NSInteger comment;
/* 新浪加v */
@property(nonatomic,assign,getter=isSina_v)BOOL sina_v;
/* 小图 */
@property(nonatomic,copy)NSString *small_image;
/* 大图 */
@property(nonatomic,copy)NSString *large_image;
/* 中图 */
@property(nonatomic,copy)NSString *middle_image;
/* 宽度 */
@property(nonatomic,copy)NSString *width;
/* 高度 */
@property(nonatomic,copy)NSString *height;
/* ID */
@property(nonatomic,copy)NSString *ID;
/* 加载更多的参数 */
@property(nonatomic,copy)NSString *maxtime;
@end
