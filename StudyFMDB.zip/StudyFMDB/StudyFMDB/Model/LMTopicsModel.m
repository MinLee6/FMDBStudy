//
//  LMTopicsModel.m
//  百思不得姐
//
//  Created by limin on 16/6/21.
//  Copyright © 2016年 limin. All rights reserved.
//帖子

#import "LMTopicsModel.h"
#import <MJExtension.h>
@implementation LMTopicsModel
+(NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{
             @"small_image":@"image0",
             @"middle_image":@"image2",
             @"large_image":@"image1",
             @"ID":@"id"
             };
}
@end
