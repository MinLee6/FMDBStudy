//
//  LMListModel.h
//  StudyFMDB
//
//  Created by limin on 16/12/5.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LMListModel : NSObject
/* 名称 */
@property(nonatomic,copy)NSString *title;
/* ID */
@property(nonatomic,copy)NSString *Id;
@end
