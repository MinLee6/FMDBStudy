//
//  DataBaseTool.h
//  StudyFMDB
//
//  Created by limin on 16/12/7.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataBaseTool : NSObject
//创建单利对象，防止创建多个数据库
+(DataBaseTool *)shareDataBaseTool;
//插入数据
-(void)insertModelArray:(NSMutableArray *)modelArray  byPrKey:(NSString *)PrKey;
//查询数据
-(NSMutableArray *)queryModelArrayByPrKey:(NSString *)PrKey;
//删除数据
-(void)deleteModelArrayByPrKey:(NSString *)PrKey;
//查询所有数据
-(void)queryAll;
//删除所有数据
-(void)clearAll;
@end
