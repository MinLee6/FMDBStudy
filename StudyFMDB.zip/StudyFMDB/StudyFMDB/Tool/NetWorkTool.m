//
//  NetWorkTool.m
//  StudyFMDB
//
//  Created by limin on 16/12/5.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import "NetWorkTool.h"
#import <AFNetworking.h>
#import "MBProgressHUD+LM.h"
@implementation NetWorkTool
+ (void)NetRequestWithBaseURL:(NSString*)baseURL andAppendURL:(NSString*)url
                   RequestWay:(NSString*)way
                   Parameters:(id)parameters
                     finished:(void (^)(id data))finished
                      failure:(void (^)(NSError* error))failure
{
    //1.创建网络请求管理类
    AFHTTPSessionManager *sessionManager = [AFHTTPSessionManager manager];
    sessionManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html",@"text/plain", nil];
    //2.取token（项目中的应用）
    NSString *cookiesdata = @"1234567adsdsv";
    NSString *pf = @"ios";//平台
    //3.传tooken
    [sessionManager.requestSerializer setValue:cookiesdata forHTTPHeaderField:@"Token"];
    [sessionManager.requestSerializer setValue:pf forHTTPHeaderField:@"UserPlatForm"];
    //4.请求的URL
    NSString* urlPath = [baseURL stringByAppendingString:url];
   //5.发起请求
    if ([way isEqualToString:@"POST"]) {
        
        [sessionManager POST:urlPath parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
            
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            
            finished(responseObject);
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            
            failure(error);
        }];
        
    }else if ([way isEqualToString:@"GET"]) {
        [sessionManager GET:urlPath parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
            
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            
            finished(responseObject);
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            
            failure(error);
        }];
        
    }

}
- (void)NetRequestWithBaseURL:(NSString*)baseURL andAppendURL:(NSString*)url
                   RequestWay:(NSString*)way
                   Parameters:(id)parameters
                     finished:(void (^)(id data))finished
                      failure:(void (^)(NSError* error))failure
{
    
    [NetWorkTool NetRequestWithBaseURL:baseURL andAppendURL:url RequestWay:way Parameters:parameters finished:finished failure:failure];
}

@end
