//
//  DataBaseTool.m
//  StudyFMDB
//
//  Created by limin on 16/12/7.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import "DataBaseTool.h"
#import "ProjectTool.h"
#import "LMTopicsModel.h"
#import <FMDB.h>
static DataBaseTool *shareDataBase = nil;
@implementation DataBaseTool
//创建单利对象，防止创建多个数据库
+(DataBaseTool *)shareDataBaseTool
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shareDataBase = [[DataBaseTool alloc]init];
    });
    return shareDataBase;
}
//插入数据
-(void)insertModelArray:(NSMutableArray *)modelArray byPrKey:(NSString *)PrKey
{
    //存储信息
    FMDatabase *db = [FMDatabase databaseWithPath:[ProjectTool getFMDBPath]];
    if ([db open]) {
        for (LMTopicsModel *model in modelArray) {
            //创建一个社区table
            NSString *sql = [NSString stringWithFormat:
                             @"insert into %@ (prikey,name ,profile_image ,text ,create_time  ,ding ,cai  ,repost ,comment ,sina_v ,small_image ,width ,height ,ID,maxtime) values ('%@','%@','%@','%@','%@','%@','%@',%@,'%@','%@','%@','%@','%@','%@','%@')",dbTableName,PrKey,model.name,model.profile_image,model.text,model.create_time,@(model.ding),@(model.cai),@(model.repost),@(model.comment),@(model.sina_v),model.small_image,model.width,model.height,model.ID,model.maxtime];
            BOOL res = [db executeUpdate:sql];
            if (!res) {
                NSLog(@"更新失败!");
            }else{
                NSLog(@"成功！");
            }
        }
        [db close];
        
    }
}
//查询数据query
-(NSMutableArray *)queryModelArrayByPrKey:(NSString *)PrKey
{
    FMDatabase *db = [FMDatabase databaseWithPath:[ProjectTool getFMDBPath]];
    NSMutableArray *dbArray = [NSMutableArray array];
    if ([db open]) {
        NSString *sql = [NSString stringWithFormat:@"select * from %@ where prikey = '%@'",dbTableName,PrKey];
        //执行sql查询语句
        FMResultSet *rs = [db executeQuery:sql];
        while ([rs next]) {
            LMTopicsModel *model = [[LMTopicsModel alloc]init];
            model.name = [rs stringForColumn:@"name"];
            model.profile_image = [rs stringForColumn:@"profile_image"];
            model.text = [rs stringForColumn:@"text"];
            model.create_time = [rs stringForColumn:@"create_time"];
            model.ding = [[rs stringForColumn:@"ding"] integerValue];
            model.cai = [[rs stringForColumn:@"cai"] integerValue];
            model.repost = [[rs stringForColumn:@"repost"] integerValue];
            model.comment = [[rs stringForColumn:@"comment"] integerValue];
            model.sina_v = [[rs stringForColumn:@"sina_v"] integerValue];
            model.small_image = [rs stringForColumn:@"small_image"];
            model.width = [rs stringForColumn:@"width"];
            model.height = [rs stringForColumn:@"height"];
            model.ID = [rs stringForColumn:@"ID"];
            model.maxtime = [rs stringForColumn:@"maxtime"];
            [dbArray addObject:model];
        }
        [db close];
    }
    return dbArray;
}
//删除数据
-(void)deleteModelArrayByPrKey:(NSString *)PrKey
{
    FMDatabase *db = [FMDatabase databaseWithPath:[ProjectTool getFMDBPath]];
    if ([db open]) {
        NSString *sql = [NSString stringWithFormat:@"delete from %@ where prikey = '%@'",dbTableName,PrKey];
        BOOL res = [db executeUpdate:sql];
        if (!res) {
            NSLog(@"删除失败");
        }else
        {
            NSLog(@"删除成功！");
        }
        [db close];
    }
}
//查询所有数据
-(void)queryAll
{
    FMDatabase *db = [FMDatabase databaseWithPath:[ProjectTool getFMDBPath]];
    if ([db open]) {
        int i = 0;
        NSString * sql = [NSString stringWithFormat:@"select * from %@",dbTableName];
        FMResultSet * rs = [db executeQuery:sql];
        while ([rs next]) {
            NSString *ID = [rs stringForColumn:@"ID"];
            NSString *text = [rs stringForColumn:@"text"];
            NSLog(@"查询的数据 %d,%@,%@",i++,ID,text);
        }
        [db close];
    }
}
//删除所有数据
-(void)clearAll
{
    FMDatabase *db = [FMDatabase databaseWithPath:[ProjectTool getFMDBPath]];
    if ([db open]) {
        NSString * sql =[NSString stringWithFormat:@"delete from %@",dbTableName];
        BOOL res = [db executeUpdate:sql];
        if (!res) {
            NSLog(@"清除失败！");
        }else
        {
            NSLog(@"清除完成！");
        }
    }
}
@end
