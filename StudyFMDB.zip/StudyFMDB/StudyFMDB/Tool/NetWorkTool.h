//
//  NetWorkTool.h
//  StudyFMDB
//
//  Created by limin on 16/12/5.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NetWorkTool : NSObject
/**
 *  访问网络请求
 *
 *  @param url        请求网址
 *  @param way        请求方式（GET/POST）
 *  @param parameters 参数列表（字典）
 *  @param finished   完成回调
 *  @param failure  出错回调
 */
+ (void)NetRequestWithBaseURL:(NSString*)baseURL andAppendURL:(NSString*)url
                   RequestWay:(NSString*)way
                   Parameters:(id)parameters
                     finished:(void (^)(id data))finished
                      failure:(void (^)(NSError* error))failure;

- (void)NetRequestWithBaseURL:(NSString*)baseURL andAppendURL:(NSString*)url
                   RequestWay:(NSString*)way
                   Parameters:(id)parameters
                     finished:(void (^)(id data))finished
                      failure:(void (^)(NSError* error))failure;
@end
