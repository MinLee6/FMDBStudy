//
//  ProjectTool.m
//  StudyFMDB
//
//  Created by limin on 16/12/7.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import "ProjectTool.h"
#define DATABASE_FILE_NAME @"project.sqlite"
@implementation ProjectTool
+(NSString *)getFMDBPath
{
    /*===---===
     在这个部分中我么进行一下操作：（要把数据库文件存放到储存的位置中）
     1.获取应用程序的路径，在手机中就是 应用程序存储数据的地方
     2.把数据库文件的名称拼接到上面得到的路径上
     3.根据拼接好的路径去寻找，并判断这个文件是否存在
     ===---===*/
    //获取应用程序的路径
    NSArray *searchPaths = NSSearchPathForDirectoriesInDomains(
                                                               NSDocumentDirectory,
                                                               NSUserDomainMask,
                                                               YES);
    NSString *documentFolderPath = [searchPaths objectAtIndex:0];
    //往应用程序路径中添加数据库文件名称，把它们拼接起来， 这里用到了宏定义（目的是不易出错)
    NSString *dbFilePath = [documentFolderPath stringByAppendingPathComponent:DATABASE_FILE_NAME];
    
    return dbFilePath;
}
@end
