//
//  ProjectTool.h
//  StudyFMDB
//
//  Created by limin on 16/12/7.
//  Copyright © 2016年 君安信（北京）科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ProjectTool : NSObject
/*获取FMDB数据库的路径*/
+(NSString *)getFMDBPath;
@end
